package upgrad;

import com.mongodb.client.*;
import org.bson.Document;
import java.sql.*;

public class Driver extends CRUDHelper {
    /**
     * Driver class main method
     * @param args
     * @throws SQLException
     */
    public static void main(String[] args) throws SQLException {
        // MySql credentials
        String url = "jdbc:mysql://pgc-sd-bigdata.cyaielc9bmnf.us-east-1.rds.amazonaws.com:3306/pgcdata";
        String user= "student";
        String password= "STUDENT123";

        // MongoDB Configurations

        Connection sqlConnection = DriverManager.getConnection(url , user , password);;
        if(sqlConnection != null){
            System.out.println("Connected to the database");
        }
        // Connection Default Value Initialization
        MongoClient mongoClient = MongoClients.create("mongodb://ec2-100-26-139-226.compute-1.amazonaws.com");
        System.out.println(mongoClient);




      try {
          // Creating database connections
          //Creating Database Upgrad
          MongoDatabase mongoDatabase = mongoClient.getDatabase("upgrad");
          //Creating Collection Products
          MongoCollection<Document> productCollection = mongoDatabase.getCollection("products");

          // Import data into MongoDb
          Statement statement = sqlConnection.createStatement();
          //Selecting Data from Table mobiles
          String sql = "select * from mobiles";
          ResultSet resultSet = statement.executeQuery(sql);
          ResultSetMetaData rsmd = resultSet.getMetaData();
          int columnsNumber = rsmd.getColumnCount();
          while (resultSet.next()) {
              //Creating New Document and saving resultset from table mobiles into Doc
              Document doc = new Document();
              for (int i = 1; i <= columnsNumber; i++) {
                  if (i > 1) System.out.print(":  ");
                  String columnValue = resultSet.getString(i);
                  System.out.print(rsmd.getColumnName(i) + ": " + columnValue + "\n");
                  doc.append(rsmd.getColumnName(i), columnValue);
              }
              System.out.println("");
              //Inserting data with additional Field category
              doc.append("category", "mobile");
              mongoDatabase.getCollection("products").insertOne(doc);
              System.out.println("Document inserted successfully");
          }


          //Selecting Data from Table cameras
          String sql1 = "select * from cameras";
          ResultSet resultSet1 = statement.executeQuery(sql1);
          ResultSetMetaData rsmd1 = resultSet1.getMetaData();
          int columnsNumber1 = rsmd1.getColumnCount();
          while (resultSet1.next()) {
              //Creating New Document and saving resultset from table cameras into Doc
              Document doc1 = new Document();
              for (int i = 1; i <= columnsNumber1; i++) {
                  if (i > 1) System.out.print(":  ");
                  String columnValue = resultSet1.getString(i);
                  System.out.print(rsmd1.getColumnName(i) + ": " + columnValue + "\n");
                  doc1.append(rsmd1.getColumnName(i), columnValue);
              }
              System.out.println("");
              //Inserting data with additional Field category
              doc1.append("category", "camera");
              mongoDatabase.getCollection("products").insertOne(doc1);
              System.out.println("Document inserted successfully");
          }

              //Selecting Data from Table headphones
              String sql2 = "select * from headphones";
              ResultSet resultSet2 = statement.executeQuery(sql2);
              ResultSetMetaData rsmd2 = resultSet2.getMetaData();
              int columnsNumber2 = rsmd2.getColumnCount();

              while (resultSet2.next()) {
                  //Creating New Document and saving resultset from table headphones into Doc
                  Document doc2 = new Document();
                  for (int i = 1; i <= columnsNumber2; i++) {
                      if (i > 1) System.out.print(":  ");
                      String columnValue = resultSet2.getString(i);
                      System.out.print(rsmd2.getColumnName(i) + ": " + columnValue + "\n");
                      doc2.append(rsmd2.getColumnName(i), columnValue);
                  }
                  System.out.println("");
                  //Inserting data with additional Field category
                  doc2.append("category", "headphones");
                  mongoDatabase.getCollection("products").insertOne(doc2);
                  System.out.println("Document inserted successfully");
              }


              // List all products in the inventory
              displayAllProducts(productCollection);

              // Display top 5 Mobiles
              displayTop5Mobiles(productCollection);

              // Display products ordered by their categories in Descending Order Without autogenerated Id
              displayCategoryOrderedProductsDescending(productCollection);

              // Display product count in each category
              displayProductCountByCategory(productCollection);

              // Display wired headphones
              displayWiredHeadphones(productCollection);

      }
        catch(Exception ex) {
            System.out.println("Got Exception.");
            ex.printStackTrace();
        }
        finally {
          //Closing Connection with MongoDB
          mongoClient.close();
          System.out.println("Closed MongoDB connection");

          //Closing Connection with SQL
          sqlConnection.close();
          System.out.println("Closed SQL connection");
        }
    }
}